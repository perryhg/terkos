#!/bin/sh
set -x

if [ -n "$HOSTARCH" ] ; then
  hostspec=--host=$HOSTARCH
  if [ -z "$CROSS_COMPILE" ] ; then 
     export CROSS_COMPILE=${HOSTARCH}-
  fi
fi

export WANT_AUTOCONF_2_5=1
rm -f etc/Makefile
rm -f aclocal.m4
libtoolize --force --copy
aclocal
autoconf
autoheader
automake -a -c

CC=${CROSS_COMPILE}gcc LD=${CROSS_COMPILE}ld ./configure $hostspec --prefix=/usr --enable-shared --with-ipkglibdir=/usr/lib

