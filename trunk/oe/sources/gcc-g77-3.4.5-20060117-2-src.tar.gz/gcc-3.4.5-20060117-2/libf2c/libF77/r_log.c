#include "f2c.h"

#undef abs
#include <math.h>
double
r_log (real * x)
{
  return (log (*x));
}
