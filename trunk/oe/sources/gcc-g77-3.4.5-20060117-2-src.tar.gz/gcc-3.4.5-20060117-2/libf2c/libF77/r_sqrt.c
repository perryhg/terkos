#include "f2c.h"

#undef abs
#include <math.h>
double
r_sqrt (real * x)
{
  return (sqrt (*x));
}
