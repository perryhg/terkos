#include "f2c.h"

#undef abs
#include <math.h>
double
d_acos (doublereal * x)
{
  return (acos (*x));
}
