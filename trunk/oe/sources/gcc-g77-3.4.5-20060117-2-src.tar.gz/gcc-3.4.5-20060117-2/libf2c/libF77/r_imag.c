#include "f2c.h"

double
r_imag (complex * z)
{
  return (z->i);
}
