#include "f2c.h"

extern double erf (double);
double
G77_erf_0 (real * x)
{
  return (erf (*x));
}
