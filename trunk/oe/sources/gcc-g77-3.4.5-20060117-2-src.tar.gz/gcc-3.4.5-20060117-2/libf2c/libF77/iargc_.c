#include "f2c.h"

ftnint
G77_iargc_0 (void)
{
  extern int f__xargc;
  return (f__xargc - 1);
}
