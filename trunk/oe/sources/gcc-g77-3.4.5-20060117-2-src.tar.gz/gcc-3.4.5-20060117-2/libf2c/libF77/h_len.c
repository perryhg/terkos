#include "f2c.h"

shortint
h_len (char *s __attribute__ ((__unused__)), ftnlen n)
{
  return (n);
}
