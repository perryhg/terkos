#include "f2c.h"

double
d_prod (real * x, real * y)
{
  return ((*x) * (*y));
}
