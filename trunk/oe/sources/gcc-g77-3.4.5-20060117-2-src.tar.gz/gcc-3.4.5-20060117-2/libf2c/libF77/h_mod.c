#include "f2c.h"

shortint
h_mod (short *a, short *b)
{
  return (*a % *b);
}
