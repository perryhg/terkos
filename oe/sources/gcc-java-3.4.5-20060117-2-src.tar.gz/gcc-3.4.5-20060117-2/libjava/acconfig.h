/* Define to `int' if `ssize_t' is not defined.  */
#undef ssize_t
