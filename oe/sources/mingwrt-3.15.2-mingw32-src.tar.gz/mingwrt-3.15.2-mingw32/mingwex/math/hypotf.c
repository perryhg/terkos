#include <math.h>

float hypotf (float x, float y)
  { return (float) _hypot (x, y);}
