#include <math.h>
float coshf (float x)
  {return (float) cosh (x);}
