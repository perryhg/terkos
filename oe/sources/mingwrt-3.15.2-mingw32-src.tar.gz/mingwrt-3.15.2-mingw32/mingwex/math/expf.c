#include <math.h>
float expf (float x)
  {return (float) exp (x);}
