long double
fmal ( long double _x,  long double _y,  long double _z)
{
  return ((_x * _y) + _z);
}
