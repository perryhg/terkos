#include <stdlib.h>
long long wtoll(const wchar_t * _w)
 	{ return _wtoi64 (_w); }
