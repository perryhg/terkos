#include <stdlib.h>
char* lltoa(long long _n, char * _c, int _i)
	{ return _i64toa (_n, _c, _i); }
