#define IN_LIBGCC2_S 1
#include "darwin-ldouble.c"
